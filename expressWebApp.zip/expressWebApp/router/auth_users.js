const express = require('express');
const jwt = require('jsonwebtoken');
let books = require("./booksdb.js");
const regd_users = express.Router();

let users = [];

const isValid = (username) => { //returns boolean
    //write code to check is the username is valid
    const result = users.filter((data) => data.username === username);
    if (result.length > 0) {
        return true;
    } else {
        return false;
    }
}

const authenticatedUser = (username, password) => { //returns boolean
    //write code to check if username and password match the one we have in records.
    let validUser = users.filter(data=>data.username === username && data.password === password);
    if(validUser.length >0 )
    {
        return true;
    }else{
        return false;
    }
}
//only registered users can login
regd_users.post("/login", (req, res) => {
    //Write your code here
    let username = req.body.username;
    let password = req.body.password;
    if(!username || !password)
    {
       return res.status(404).json("Please provide username & password");
    }

    if(authenticatedUser(username , password))
    {
        let accessToken = jwt.sign({data:username},'access',{expiresIn : 60 * 60});
        console.log(accessToken);
        req.session.authorization = {
            accessToken,username
        }
        console.log( req.session.authorization);
        return res.status(200).json({message:"User login successfully"});
    }else{
        return res.status(208).send("Invalid User session");
    }
});

// Add a book review
regd_users.put("/review/:isbn", (req, res) => {
    
    //Write your code here
    const username = req.body.username;
    const password = req.body.password;
    const isBnNumber = req.params.isbn;
    const review = req.body.review;
    if(username && password && authenticatedUser(username, password) && isBnNumber)
    {
        for (const key in books) {
           if(key === isBnNumber)
           {
            books[key].reviews = {username:username,review:review}
            return res.status(200).json({result:books[key]});
           }
        }
    }
});


// delete user review
regd_users.delete('/deleteReview/:username',(req,res)=>{
    const username = req.params.username;
    const password = req.body.password;
    console.log(username, password);
    if(username && authenticatedUser(username,password))
    {
        for (const key in books) {
            if(books[key].reviews.username === username)
            {
                books[key].reviews = {};
                return res.status(200).json({result:books[key]});
            }
        }
    }
})

module.exports.authenticated = regd_users;
module.exports.isValid = isValid;
module.exports.users = users;
