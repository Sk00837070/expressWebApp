const express = require('express');
let books = require("./booksdb.js");
const axios = require('axios');
let isValid = require("./auth_users.js").isValid;
let users = require("./auth_users.js").users;
const public_users = express.Router();

// get all books by async function with axios
public_users.get('/books',  (req,res)=>{
  (async ()=>{
    try{
      const response = await axios.get('http://localhost:5000/');
     return res.status(200).json({result:response.data});
    }catch(error){
      console.log(error);
    }
  })();
});

public_users.get('/searchisbn/:isbn',  (req,res)=>{
  (async ()=>{
    try{
      const isbn = req.params.isbn;
      const response = await axios.get(`http://localhost:5000/isbn/${isbn}`);
      return res.status(200).json({result:response.data});
    }catch(error){
      console.log(error);
    }
  })();
});

public_users.get('/searchTitle/:title',  (req,res)=>{
  (async ()=>{
    try{
      const title = req.params.title;
      const response = await axios.get(`http://localhost:5000/title/${title}`);
      return res.status(200).json({result:response.data});
    }catch(error){
      console.log(error);
    }
  })();
});

public_users.get('/searchAuthor/:author',  (req,res)=>{
  (async ()=>{
    try{
      const author = req.params.author;
      const response = await axios.get(`http://localhost:5000/author/${author}`);
      return res.status(200).json({result:response.data});
    }catch(error){
      console.log(error);
    }
  })();
});

public_users.post("/register", (req,res) => {
  //Write your code here
  const username = req.body.username;
  const password = req.body.password;
  if(!isValid(username))
  {
    users.push({username:username,password:password});
    return res.status(200).json({message: ""+username+""+ " register added successfully"});
  }else{
    return res.status(300).json({message: "Please provide username and password to register!"});
  }
});

// Get the book list available in the shop
public_users.get('/',function (req, res) {
  //Write your code here
  return res.status(200).json({result: books});
});

// Get book details based on ISBN
public_users.get('/isbn/:isbn',function (req, res) {
  //Write your code here
  const isbnNumber = req.params.isbn;
  if(isbnNumber)
  {
    for (const key in books) {
      if(isbnNumber === key)
      {
        return res.status(200).json({result: books[key]});
      }
    }
  }
 });
  
// Get book details based on author
public_users.get('/author/:author',function (req, res) {
  //Write your code here
  const author = req.params.author;
  if(author)
  {
    for (const key in books) {
      if(books[key].author === author)
      {
        return res.status(200).json({result: books[key]});
      }
    }
  }
});

// Get all books based on title
public_users.get('/title/:title',function (req, res) {
  //Write your code here
  const title = req.params.title;
  if(title)
  {
    for (const key in books) {
      if(books[key].title === title)
      {
        return res.status(200).json({message: books[key]});
      }
    }
  }
});

//  Get book review
public_users.get('/auth/review/:isbn',function (req, res) {
  //Write your code here
  const isbnNumber = req.params.isbn;
  if(isbnNumber)
  {
    for (const key in books) {
      if(key === isbnNumber)
      {
        return res.status(200).json({review: books[key].reviews});
      }
    }
  }
});

module.exports.general = public_users;
